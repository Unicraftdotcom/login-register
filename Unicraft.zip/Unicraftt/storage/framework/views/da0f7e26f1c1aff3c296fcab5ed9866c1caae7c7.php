<?php $__env->startSection('title', 'Unicraft | Register'); ?>
<link rel="stylesheet" href="/css/style.css">

<?php $__env->startSection('navbar'); ?>
    <nav class="navbar fixed-top navbar-expand-lg bg-light shadow p-3 mb-5 bg-white">
        <a href="/" class="navbar-brand">
            <img src="/img/logo.png" height="70px" alt="logo-unicraft"> 
        </a>
        <ul class="nav justify-content-end">
            <li class="nav-item">
                <a href="/artist" class="nav-link">MEET THE ARTIST</a>
            </li>
            <li class="nav-item">
                <a href="/search" class="nav-link">SEARCH</a>
            </li>
            <li class="nav-item">
                <a href="/login" class="nav-link">LOGIN OR JOIN</a>
            </li>
            
            <li class="nav-item">
                <a href="" class="nav-link"><i class="material-icons">shopping_cart</i>0</a>
            </li>
        </ul>
        <i class="material-icons nav-link toggle">menu</i>
    </nav>
    <div class="menu-responsive shadow-lg p-3 mb-5 bg-white">
        <center><img src="/img/logo.png" alt=""></center>
        <ul class="nav flex-column ">
            <li class="nav-item"><a href="/artist" class="nav-link">MEET THE ARTIST</a></li>
            <li class="nav-item"><a href="/login" class="nav-link">LOGIN OR JOIN</a></li>
            <li class="nav-item"><a href="/search" class="nav-link">SEARCH</a></li>
            <li class="nav-item"><a href="" class="nav-link"><i class="material-icons">shopping_cart</i>CART 0</a></li>
        </ul>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(count($errors)>0): ?>
        <div id="error" style="display:none;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <div class="container">
        <div class="row" style="overflow-x:hidden;">
            <div class="col col-8" style="margin:10% auto;">
                <div class="card shadow p-3 mb-5 bg-white rounded">
                    <center><h5 style="color:#ca4540;">R E G I S T E R</h5></center>
                    <form action="<?php echo e(route('register')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="nameControlInput">Name</label>
                            <input type="text" name="name" id="nameControlInput" class="form-control" placeholder="Nama Anda" value="<?php echo e(old('name')); ?>">
                            
                        </div>
                        <div class="form-group">
                            <label for="emailControlInput">E-mail</label>
                            <input type="email" name="email" id="emailControlInput" class="form-control" placeholder="Email Anda" value="<?php echo e(old('email')); ?>">
                            
                        </div>
                        <div class="form-group">
                            <label for="emailControlInput">No Telp/Hp</label>
                            <input type="number" name="noHp" id="emailControlInput" class="form-control" placeholder="No Telp/Hp Anda" value="<?php echo e(old('noHp')); ?>">
                            
                        </div>
                        <p>Jenis kelamin</p>
                        <div class="row">
                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" value="Laki-laki">
                                    <label class="form-check-label">
                                    Laki-laki
                                    </label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" value="Perempuan">
                                    <label class="form-check-label">
                                    Perempuan
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="passControlInput">Password</label>
                            <input type="password" name="password" id="passControlInput" class="form-control" placeholder="Password" value="<?php echo e(old('password')); ?>">
                            
                        </div>
                        <div class="form-group">
                            <label for="passControlInput">Konfirmasi Kata Sandi</label>
                            <input type="password" name="password_confirmation" id="passControlInput" class="form-control" placeholder="Konfirmasi Password Anda" value="<?php echo e(old('password')); ?>">
                            
                        </div>
                        <div class="form-group">
                            <label for="passControlInput">Konfirmasi Kata Sandi</label>
                            <input type="hidden" name="hakAkses" value="user">
                            
                        </div>
                        <button type="submit" class="btn btn-primary mb-2" style="background-color: #ca4540;outline: none;border: none;">Register</button><br>
                        <span>Sudah punya akun?</span><a href="/login" style="color:#ca4540;">Klik disini</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.26.11/dist/sweetalert2.all.min.js"></script>
<script>
    var has_error = <?php echo e($errors->count() > 0 ? 'true' : 'false'); ?>;
    if (has_error) {
        swal({
            title: 'ERROR!',
            type : 'error',
            html : jQuery('#error').html(),
            showCloseButton : true,
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>