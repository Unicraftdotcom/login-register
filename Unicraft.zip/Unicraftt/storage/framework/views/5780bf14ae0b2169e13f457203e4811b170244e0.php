<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="/img/logoo.png">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<!-- bootstrap CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" >
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>
    <!-- End -->
    <!-- jquery CDN -->
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/push.js/1.0.5/push.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <!-- End -->
    <!-- Set your CSS file below -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">
    <script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
    <script src="/js/app.js"></script>
    <!-- end -->
</head>
<body>
	<nav class="navbar fixed-top navbar-expand-lg bg-light shadow p-3 mb-5 bg-white">
        <a href="/" class="navbar-brand">
            <img src="/img/logo.png" height="70px" alt="logo-unicraft"> 
        </a>
        <ul class="nav justify-content-end">
            <li class="nav-item">
                
                <a href="#" id="comsoon" class="nav-link">COMING SOON</a>
            </li>
            
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a href="/login" class="nav-link">LOGIN OR JOIN</a>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <a href="#" id="comsoon" class="nav-link"><?php echo e(Auth::user()->name); ?></a>
                </li>
                <li class="nav-item">
                    <a href="/logout" class="nav-link">Logout</a>
                </li>
            <?php endif; ?>
            
        </ul>
        <i class="material-icons nav-link toggle">menu</i>
    </nav>
    <div class="menu-responsive shadow-lg p-3 mb-5 bg-white">
        <center><a href="/"><img src="/img/logo.png" alt=""></a></center>
        <ul class="nav flex-column ">
            <li class="nav-item">
                
                <a href="#" id="comsoon" class="nav-link">COMING SOON</a>
            </li>
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a href="/login" class="nav-link">LOGIN OR JOIN</a>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <a href="#" id="comsoon" class="nav-link"><?php echo e(Auth::user()->name); ?></a>
                </li>
                <li class="nav-item">
                    <a href="/logout" class="nav-link">Logout</a>
                </li>
            <?php endif; ?>
            <li class="nav-item">
                
                
            </li>
            
        </ul>
    </div>
    <?php echo $__env->yieldContent('content'); ?>
    <footer class="mainfooter" role="contentinfo">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12">
                        <center><h4>Contact Us</h4></center>
                        <ul class="list-unstyled">
                            <li>info@the-unicraft.com</li>
                            <li>katharinaester1407@gmail.com</li>
                            <li>daryakartika@gmail.com</li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-sm-12">
                        <center><h4>Services</h4></center>
                        <ul class="list-unstyled">
                            <li><a href="#">Ordering & Payment</a></li>
                            <li><a href="#">Shipping</a></li>
                            <li><a href="#">Returns</a></li>
                            <li><a href="#">FAQ</a></li>
                            <li><a href="#">Sizing guide</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-sm-12">
                        <center><h4>Information</h4></center>
                        <ul class="list-unstyled">
                            <li><a href="#">Work with Us</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Terms & Conditions</a></li>
                            <li><a href="#">Press Enquiries</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-sm-12">
                        <div class="float-right">
                           <a href="https://instagram.com/unicraftdotcom" title="unicraftdotcom" target="_blank"><img src="/img/instagram-logo.png" target="_blank" alt="ig-logo"></a>
                           <a href="#"><img src="/img/facebook-logo-button.png" alt="fb-logo"></a>
                           <a href="https://www.youtube.com/channel/UCb03wqrVf87a7tT8iWmbv2A" target="_blank" title="Unicraft TV"><img src="/img/yt.png" alt="yt-logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-middle">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <center><h6>&copy; Copyright Unicraft 2018</h6></center>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>