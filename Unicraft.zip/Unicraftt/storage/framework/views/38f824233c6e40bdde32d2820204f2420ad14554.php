<?php $__env->startSection('title', 'Unicraft | Beranda'); ?>
<link rel="stylesheet" href="/css/style.css">
<?php $__env->startSection('content'); ?>;
        <div class="main-carousel">
            <div class="carousel-cell" style="background-image: url('/Img/hero-bg.jpg');">
                sa
            </div>
            <div class="carousel-cell" style="background-image: url('/Img/hero-bg-2.jpg');">
                sa
            </div>
            <div class="carousel-cell" style="background-image: url('/Img/hero-bg3.jpg');">
                sa
            </div>
        </div>
    <div class="container">
        <h5>Category</h5>
        <div class="row">
            <div class="col col1">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;border:none;">
                    <img src="/img/acc.jpg" alt="Accessoris" class="card-img-top" height="100px">
                    <div class="card-body">
                        <center><h5>Accessoris</h5></center>
                    </div>
                </div>
            </div>
            <div class="col col2">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/Garment.jpg" alt="Garment" class="card-img-top" height="100px">
                    <div class="card-body">
                        <center><h5>Garment</h5></center>
                    </div>
                </div>
            </div>
            <div class="col col3">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/Furniture.jpg" alt="Furniture" class="card-img-top" height="100px">
                    <div class="card-body">
                        <center><h5>Furniture</h5></center>
                    </div>
                </div>
            </div>
            <div class="col col4">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/food.jpg" alt="Food" class="card-img-top" height="100px">
                    <div class="card-body">
                        <center><h5>Food</h5></center>
                    </div>
                </div>
            </div>
            <div class="col col5">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/craft.jpg" alt="Craft" class="card-img-top" height="100px">
                    <div class="card-body">
                        <center><h5>Craft</h5></center>
                    </div>
                </div>
            </div>
        </div>
        <h5>Meet the Artist</h5>
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-12">
                <div class="card" style="width:100%;">
                    <img src="/img/hero-bg.jpg" alt="Accessoris" class="card-img-top">
                    <div class="card-body shadow p-3 mb-5 bg-white rounded">
                        <h5 class="card-title">Lorem Ipsum</h5>
                        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia ea facere facilis atque voluptates officia provident, dolores doloremque obcaecati, inventore repudiandae neque quas dolorem, ducimus explicabo cumque odit ab soluta.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12">
                <div class="card">
                    <img src="/img/hero-bg.jpg" alt="Accessoris" class="card-img-top">
                    <div class="card-body shadow p-3 mb-5 bg-white rounded">
                        <h5 class="card-title">Lorem Ipsum</h5>
                        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia ea facere facilis atque voluptates officia provident, dolores doloremque obcaecati, inventore repudiandae neque quas dolorem, ducimus explicabo cumque odit ab soluta.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12">
                <div class="card" style="width:100%;">
                    <img src="/img/hero-bg.jpg" alt="Accessoris" class="card-img-top">
                    <div class="card-body shadow p-3 mb-5 bg-white rounded">
                        <h5 class="card-title">Lorem Ipsum</h5>
                        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia ea facere facilis atque voluptates officia provident, dolores doloremque obcaecati, inventore repudiandae neque quas dolorem, ducimus explicabo cumque odit ab soluta.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12">
                <div class="card" style="width:100%;">
                    <img src="/img/hero-bg.jpg" alt="Accessoris" class="card-img-top">
                    <div class="card-body shadow p-3 mb-5 bg-white rounded">
                        <h5 class="card-title">Lorem Ipsum</h5>
                        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia ea facere facilis atque voluptates officia provident, dolores doloremque obcaecati, inventore repudiandae neque quas dolorem, ducimus explicabo cumque odit ab soluta.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
        </div>
        <center>
            <h2>Subscribe Us</h2>
            <span>Masukkan email kamu dibawah ini untuk mendapatkan info tentang kami</span>
            <form action="<?php echo e(route('mail')); ?>" method="post">
                <div class="row">
                    <div class="col col-6" style="margin: 0 auto;">
                        <div class="form-group">
                            <input class="form-control"  type="email" name="email" placeholder="Masukkan email kamu disini" id="valid" required><br>
                            <input type="submit" value="submit" class="btn btn-primary">
                        </div>
                    </div>
                </div>
                <?php echo e(csrf_field()); ?>

            </form>
        </center>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.26.11/dist/sweetalert2.all.min.js"></script>
    <script>
    $(document).ready(function(){
        $('.main-carousel').flickity({
            // options
            cellAlign: 'left',
            contain: true,
            freeScroll: true,
            wrapAround: true,
        });
        // var input = $('#valid').val();
        // if (input > 0) {
        //         swal({
        //         title: 'Terimakasih',
        //         type : 'success',
        //         html : jQuery('#error').html(),
        //         showCloseButton : true,
        //     });
        // }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>