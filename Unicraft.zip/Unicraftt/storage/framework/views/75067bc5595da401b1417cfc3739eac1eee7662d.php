<?php $__env->startSection('title', 'Unicraft | Login'); ?>
<link rel="stylesheet" href="/css/style.css">
<?php $__env->startSection('content'); ?>;
    <div class="container">
        <div class="row" style="overflow-x:hidden;">
            <div class="col col-12" style="margin:5% auto;">
                <div class="row login">
                    <div class="col-lg-3 col-md-6 img" style="background:url('/img/hero-bg.jpg');background-repeat:no-repeat;width:100%;height:auto;padding:0;"></div>
                    <div class="col-lg-3 col-md-6" style="padding:0;">
                        <div class="card shadow p-3 mb-5 bg-white rounded">
                            <center><h5 style="color:#ca4540;">L O G I N</h5></center>
                            <form action="<?php echo e(route('login')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="emailControlInput">E-mail</label>
                                    <input type="email" name="email" id="emailControlInput" class="form-control" placeholder="Email Anda" value="<?php echo e(old('email')); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="passControlInput">Kata Sandi</label>
                                    <input type="password" name="password" id="passControlInput" class="form-control" placeholder="Password Anda" value="<?php echo e(old('password')); ?>" required>
                                </div>
                                <button type="submit" class="btn btn-primary mb-2" style="background-color: #ca4540;outline: none;border: none;">Masuk</button><br>
                                <span>Belum punya akun?</span><a href="/register" style="color:#ca4540;">Klik disini</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script src="/js/sweetalert.min.js"></script>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>