<?php $__env->startSection('title','Unicraft | Search'); ?>

<link rel="stylesheet" href="/css/style (2).css">
<link rel="stylesheet" type="text/css" href="/css/search.css">
<?php $__env->startSection('content'); ?>
 <div class="container">
        <div class="row">
            <div class="col col-12">
                <form class="example">
                    <input type="text" placeholder="Cari semuanya disini.." name="search">
                    <button type="submit"><i>search</i></button>
                </form>
            </div>
        </div>
    </div>
<nav class="categori">
    <ul class="nav justify-content-center">
        <li class="nav-item">
            <a href="#" class="nav-link" style="color: #767676;">Accessoris</a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link" style="color: #767676;">Garment</a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link" style="color: #767676;">Furniture</a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link" style="color: #767676;">Food</a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link" style="color: #767676;">Craft</a>
        </li>
    </ul>
</nav>
<div class="container">
    <div class="row">
        <div class="col col-lg-3 col-md-6 col-sm-12">
            <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                <div class="card-body">
                    <h5 class="card-title">Turtle Craving</h5>
                    <p class="card-text">I Made Bali</p>
                </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
            </div>
        </div>
        <div class="col col-lg-3 col-md-6 col-sm-12">
            <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                <div class="card-body">
                    <h5 class="card-title">Turtle Craving</h5>
                    <p class="card-text">I Made Bali</p>
                </div>
                <div class="card-footer">
                    <a href="#" class="card-link">IDR.250.000,00</a>
                </div>
            </div>
        </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Craving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>