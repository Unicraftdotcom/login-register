@extends('layouts.master')
@section('title', 'Unicraft | Beranda')
<link rel="stylesheet" href="/css/style.css">
@section('content');
	<section class="uni-hero" style="background-image: url('/img/hero-bg.jpg');">
		<div class="overlay">
			<h1 class="hero-title">Selamat datang di Unicraft</h1>
			<b><span class="hero-span"">Maaf, situs ini masih dalam masa pembuatan</span></b>
		</div>
	</section>
	<section class="uni-category">
		<div class="container">
			<h3 style="color: #ca4540;">Category</h3>
			<center><h1 class="text-comsoon" style="color: #ca4540;">COMING SOON</h1></center>
		</div>
	</section>
	<section class="uni-artist">
		<div class="container">
			<h3 style="color: #ca4540;">Meet the artist</h3>
			<center><h1 class="text-comsoon" style="color: #ca4540;">COMING SOON</h1></center>
		</div>
	</section>
	<section class="uni-vid">
		<div class="container">
			<center><h2 style="color: #ca4540;">Our services</h2></center>
		<hr style="border-bottom: 2px solid #ca4540;border-top: 2px solid #ca4540;">
		<div class="row">
			<div class="col-lg-4">
				<div id="uniPlayer">
					<iframe width="100%" height="250" src="https://www.youtube.com/embed/1GE-ifjUqmg" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
				</div>
			</div>
			<div class="col-lg-8">
				<h2 style="color: #ca4540;">Lorem ipsum</h2>
				<hr style="border-bottom: 2px solid #ca4540;border-top: 2px solid #ca4540;margin: 0;">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi expedita doloribus eligendi optio commodi tenetur unde facere voluptatibus dolorem quas eaque, molestias recusandae officiis repellendus quibusdam corrupti dolor voluptatum sed.</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi blanditiis, aliquid voluptate sunt labore molestias nulla ex dicta fugit aperiam minima placeat autem ipsa, numquam suscipit vel modi nisi deserunt?</p>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-8">
				<h2 style="color: #ca4540;">Lorem ipsum</h2>
				<hr style="border-bottom: 2px solid #ca4540;border-top: 2px solid #ca4540;margin: 0;">
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi expedita doloribuseligendi optio commodi tenetur unde facere voluptatibus dolorem quas eaque, molestias recusandae officiis repellendus quibusdam corrupti dolor voluptatum sed.</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi blanditiis, aliquid voluptate sunt labore molestias nulla ex dicta fugit aperiam minima placeat autem ipsa, numquam suscipit vel modi nisi deserunt?</p>
			</div>
			<div class="col-lg-4">
				<div id="uniPlayer">
					<iframe width="100%" height="315" src="https://www.youtube.com/embed/FJ-ULEy8uAY" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
				</div>
			</div>
		</div>
		</div>
	</section>
	<section class="uni-subs">
		<div class="container">
			<center>
				<h2 style="color: #ca4540;">Subscribe Us</h2>
				<span>Subscribe Kami untuk mendapatkan update terbaru</span>
			</center>
			<hr style="border-bottom: 2px solid #ca4540;border-top: 2px solid #ca4540;">
		<form action="{{route('mail')}}" method="post">
            <div class="row">
                <div class="col-lg-8" style="margin: 0 auto;">
                    <div class="form-group">
                        <input class="form-control"  type="email" name="email" placeholder="Masukkan email kamu disini" id="valid" style="outline-color: #ca4540;" required><br>
                        <center><input type="submit" value="Submit" class="btn btn-primary" style="background-color: #ca4540;border:1px solid #ca4540;"></center>
                    </div>
                </div>
            </div>
            {{ csrf_field() }}
        </form>
		</div>
	</section>
@endsection