@extends('layouts.master')

@section('title','Unicraft | Product')

<link rel="stylesheet" href="/css/product-page.css">
@section('content')
    <!-- Random Product Slide -->
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img class="d-block w-100" src="Asset/Img/TurtleHolly.png" alt="First slide" style="height:500px;">
          <div class="carousel-caption d-none d-md-block">
          <h5>First Slide</h5>
          <p>Turtle Carving</p>
          </div>
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="Asset/Img/TurtleHolly.png" alt="Second slide" style="height:500px;">
          <div class="carousel-caption d-none d-md-block">
          <h5>Second Slide</h5>
          <p>Turtle Carving</p>
          </div>
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="Asset/Img/TurtleHolly.png" alt="Third slide" style="height:500px;">
          <div class="carousel-caption d-none d-md-block">
          <h5>Third Slide</h5>
          <p>Turtle Carving</p>
          </div>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
    <!-- End Random Product Slide -->
 

    <!-- Category Product -->
    <div class="container">
        <div class="row">
            <div class="col col1">
                <div class="card">
                    <div class="card-body shadow p-3 mb-5 bg-white rounded">
                        <center>
                            <a  href="" class="nav-link text-dark">
                                <img src="/img/accessoris-icon.jpg" alt="Accessoris" style="height:35px;">
                                <h5>Accessoris</h5>
                            </a>
                        </center>
                    </div>
                </div>
            </div>
            <div class="col col2">
                <div class="card">
                    <div class="card-body shadow p-3 mb-5 bg-white rounded">
                        <center>
                            <a href="" class="nav-link text-dark">
                                <img src="/img/garment-icon.jpg" alt="Garment" style="height:35px;">
                                <h5>Garment</h5>
                            </a>
                        </center>
                        
                    </div>
                </div>
            </div>
            <div class="col col3">
                <div class="card">   
                    <div class="card-body shadow p-3 mb-5 bg-white rounded">
                        <a href="" class="nav-link text-dark"><center><img src="/img/furniture-icon.jpg" alt="Furniture" style="height:35px;">
                        <h5>Furniture</h5></center>
                    </a>
                    </div>
                </div>
            </div>
            <div class="col col4">
                <div class="card">
                    <div class="card-body shadow p-3 mb-5 bg-white rounded">
                        <a href="" class="nav-link text-dark"><center><img src="/img/food-icon.jpg" alt="Food" style="height:35px;">
                        <h5>Food</h5></center></a>
                    </div>
                </div>
            </div>
            <div class="col col5">
                <div class="card">
                    <div class="card-body shadow p-3 mb-5 bg-white rounded">
                        <center>
                            <a href="" class="nav-link text-dark">
                                <img src="/img/craft-icon.jpg" alt="Craft" style="height:35px;">
                                <h5>Craft</h5>
                            </a>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    <!-- End Category Product -->

    <!-- Sequencing Product -->
        <div class="container ">
            <div class="row ">
                <div class="col text-right m-3">
                Urutan Berdasarkan : &nbsp
                <select >
                <option value="Populeritas">Populeritas</option>
                <option value="HargaTertinggi">Harga Tertinggi</option>
                <option value="HargaTerendah">Harga Terendah</option>
                </select>
                </div>
            </div>
        </div>
    <!-- End Sequencing Product -->

    <!-- List Product -->
        <div class="row">
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                         <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div> 
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
            <div class="col col-lg-3 col-md-6 col-sm-12">
                <div class="card shadow p-3 mb-5 bg-white rounded" style="width:100%;">
                    <img src="/img/TurtleHolly.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title">Turtle Carving</h5>
                        <p class="card-text">I Made Bali</p>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="card-link">IDR.250.000,00</a>
                    </div>
                </div>
            </div>   
        </div>
    </div>
    <!-- End List Product -->
@endsection