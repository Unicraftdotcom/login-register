@extends('layouts.master')

@section('title', 'Unicraft | Register')
<link rel="stylesheet" href="/css/style.css">
{{-- <link rel="stylesheet" href="/css/style.css"> --}}
@section('content')
    @if(count($errors)>0)
        <div id="error" style="display:none;">
            @foreach($errors->all() as $error)
                <li>{{$error}}</li>
            @endforeach
        </div>
    @endif
    <div class="container">
        <div class="row" style="overflow-x:hidden;">
            <div class="col col-8" style="margin:10% auto;">
                <div class="card shadow p-3 mb-5 bg-white rounded">
                    <center><h5 style="color:#ca4540;">R E G I S T E R</h5></center>
                    <form action="{{route('register')}}" method="POST">
                        {{csrf_field()}}
                        <div class="form-group">
                            <label for="nameControlInput">Name</label>
                            <input type="text" name="name" id="nameControlInput" class="form-control" placeholder="Nama Anda" value="{{old('name')}}">
                            {{-- @if($errors->has('name'))
                                <p>{{$errors->first('name')}}</p>    
                            @endif --}}
                        </div>
                        <div class="form-group">
                            <label for="emailControlInput">E-mail</label>
                            <input type="email" name="email" id="emailControlInput" class="form-control" placeholder="Email Anda" value="{{old('email')}}">
                            {{-- @if($errors->has('email'))
                                <p>{{$errors->first('email')}}</p>    
                            @endif --}}
                        </div>
                        <div class="form-group">
                            <label for="emailControlInput">No Telp/Hp</label>
                            <input type="number" name="noHp" id="emailControlInput" class="form-control" placeholder="No Telp/Hp Anda" value="{{old('noHp')}}">
                            {{-- @if($errors->has('noHp'))
                                <p>{{$errors->first('noHp')}}</p>    
                            @endif --}}
                        </div>
                        <p>Jenis kelamin</p>
                        <div class="row">
                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" value="Laki-laki">
                                    <label class="form-check-label">
                                    Laki-laki
                                    </label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" value="Perempuan">
                                    <label class="form-check-label">
                                    Perempuan
                                    </label>
                                </div>
                            </div>
                        </div>
                        {{-- @if($errors->has('gender'))
                                <p>{{$errors->first('gender')}}</p>    
                            @endif --}}
                        <div class="form-group">
                            <label for="passControlInput">Password</label>
                            <input type="password" name="password" id="passControlInput" class="form-control" placeholder="Password" value="{{old('password')}}">
                            {{-- @if($errors->has('password'))
                                <p>{{$errors->first('password')}}</p>    
                            @endif --}}
                        </div>
                        <div class="form-group">
                            <label for="passControlInput">Konfirmasi Kata Sandi</label>
                            <input type="password" name="password_confirmation" id="passControlInput" class="form-control" placeholder="Konfirmasi Password Anda" value="{{old('password')}}">
                            {{-- @if($errors->has('name'))
                                <p>{{$errors->first('name')}}</p>    
                            @endif --}}
                        </div>
                        <div class="form-group">
                            <label for="passControlInput">Konfirmasi Kata Sandi</label>
                            <input type="hidden" name="hakAkses" value="user">
                            {{-- @if($errors->has('name'))
                                <p>{{$errors->first('name')}}</p>    
                            @endif --}}
                        </div>
                        <button type="submit" id="submit" class="btn btn-primary mb-2" style="background-color: #ca4540;outline: none;border: none;">Register</button><br>
                        <span>Sudah punya akun?</span><a href="/login" style="color:#ca4540;">Klik disini</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@7.26.11/dist/sweetalert2.all.min.js"></script>
<script>
    var has_error = {{$errors->count() > 0 ? 'true' : 'false'}};
    if (has_error) {
        swal({
            title: 'ERROR!',
            type : 'error',
            html : jQuery('#error').html(),
            showCloseButton : true,
        });
    }
    // if (noError) {
    //     swal({
    //         title: 'ERROR!',
    //         type : 'error',
    //         html : jQuery('#error').html(),
    //         showCloseButton : true,
    //     });
    // }
    // if (has_error < 0) {
    //     $('#submit').click(function(e){
    //     e.preventDefault();
    //     var success = swal({
    //         title: 'Berhasil',
    //         type : 'success',
    //         html : 'Anda berhasil daftar',
    //         showCloseButton : true,
    //     });
    //     if (success) {
    //         window.location.href = '/login';
    //     }
    // });
    // }
    
    
</script>
@endsection
