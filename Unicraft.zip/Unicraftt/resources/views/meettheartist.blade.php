@extends('layouts.master')

@section('title','Unicraft | Artist')

<link rel="stylesheet" href="/css/mta-page.css">

@section('content')
    <!-- Profil ID -->
    <div class="hero-profil" style="background-image: url(/img/hero-bg.jpg);width: 100%;height: 400px; ">
    </div>
    <div class="profile-picture">
        <a href="">
           <img class="rounded-circle img-thumbnail img-profil" src="/img/TurtleHolly.jpg" alt="">
        </a>
    </div>
    <ul class="nav justify-content-start">
        <li class="nav-item-menu">
            <a href="#" class="nav-link-menu text-dark " style="text-decoration:none;">Post</a>
            <br>
            <a class="sub-item">10</a>
        </li>
        <li class="nav-item-menu">
            <a href="#" class="nav-link-menu  text-dark" style="text-decoration:none;">Following</a>
            </br>
            <a class="sub-item">100</a>
        </li>
        <li class="nav-item-menu">
            <a href="#" class="nav-link-menu  text-dark" style="text-decoration:none;">Follower</a>
            </br>
            <a class="sub-item">100</a>
        </li>
        <li class="">
            <a href="#" class="btn" style="color: #000000; " >Follow</a>
        </li>
        <li class="">
            <a href=""><i class="nav-item-menu material-icons" style="margin-left: 50%; border:1px solid black; border-radius: 50%; height: 50px; width: 50px; font-size: 30px; color: lightgrey; text-align:center; padding-top: 15%; margin-right: 0px;">mail_outline</i></a>          
        </li>
    </ul>
    
   <!-- End Profil Id -->
    <!-- Stories -->
    <div class="container">
        <h5>Stories</h5>
        <div class="row" >
            <div class="col col-lg-3 col-md-6">
                <div class="card rounded ">
                    <img src="/img/hero-bg.jpg" alt="Stories Image">
                </div>
            </div>
            <div class="col col-lg-3 col-md-6">
                <div class="card rounded ">
                    <img src="/img/hero-bg.jpg" alt="Stories Image">       
                </div>
            </div>
            <div class="col col-lg-3 col-md-6">
                <div class="card rounded ">              
                    <img src="/img/hero-bg.jpg" alt="Stories Image">   
                </div>
            </div>
            <div class="col col-lg-3 col-md-6">
                <div class="card rounded">
                    <img src="/img/hero-bg.jpg" alt="Stories Image">
                </div>
            </div>
        </div> 
    </div>       
    <!-- End Stories -->

    <!-- Timeline Profil -->
    <div class="container ">
        <div class="card shadow p-3 m-3 rounded">
            <div class="row">
                <div class="col-lg-auto">         
                    <img class="rounded-circle" src="/img/dafault-avatar.png" alt="Avatar" style="width:70px; height:70px;">
                </div>
                <div class="col-lg-11 ">
                    <h5>
                        I Made Bali
                    </h5>
                    <p class="small text-muted"> 
                        24 jam yang lalu
                    </p>
                    <br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus, ipsum laudantium consequuntur, hic veniam ut repudiandae quaerat nulla beatae quo dolore dignissimos! Fuga earum quasi explicabo, tenetur deleniti quo quis.
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12">
                    <p class="small text-muted">
                        <i class="material-icons">thumb_up_alt</i>1.1K Likes &nbsp; &nbsp;<i class="material-icons">comment</i>100 Comments
                    </p>
                </div>
            </div> 
        </div>  
        <div class="card shadow p-3 m-3 rounded">
            <div class="row">
                <div class="col-lg-auto ">         
                    <img class="rounded-circle " src="/img/dafault-avatar.png" alt="Avatar" style="width:70px; height:70px;">
                </div>
                <div class="col-lg-11 ">
                    <h5>
                        I Made Bali
                    </h5>
                    <p class="small text-muted"> 
                        24 jam yang lalu
                    </p>
                    <br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus, ipsum laudantium consequuntur, hic veniam ut repudiandae quaerat nulla beatae quo dolore dignissimos! Fuga earum quasi explicabo, tenetur deleniti quo quis.
                    <br>
                    <video src=""></video>
                    <img src="" alt="Video">
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12">
                    <p class="small text-muted">
                        <i class="material-icons">thumb_up_alt</i>1.1K Likes &nbsp; &nbsp;<i class="material-icons">comment</i>100 Comments
                    </p>
                </div>
            </div> 
        </div>
        <div class="card shadow p-3 m-3 rounded">
            <div class="row">
                <div class="col-lg-auto ">         
                    <img class="rounded-circle " src="/img/dafault-avatar.png" alt="Avatar" style="width:70px; height:70px;">
                </div>
                <div class="col-lg-11 ">
                    <h5>
                        I Made Bali
                    </h5>
                    <p class="small text-muted"> 
                        24 jam yang lalu
                    </p>
                    <br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Doloribus, ipsum laudantium consequuntur, hic veniam ut repudiandae quaerat nulla beatae quo dolore dignissimos! Fuga earum quasi explicabo, tenetur deleniti quo quis.
                    <br>
                    <div class="container">
                        <div class="row">
                            <div class="col col-lg-4"><img src="/img/hero-bg.jpg" alt="Gambar"></div>
                            <div class="col col-lg-4"><img src="/img/hero-bg.jpg" alt="Gambar"></div>
                            <div class="col col-lg-4"><img src="/img/hero-bg.jpg" alt="Gambar"></div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12">
                    <p class="small text-muted">
                        <i class="material-icons">thumb_up_alt</i>1.1K Likes &nbsp; &nbsp;<i class="material-icons">comment</i>100 Comments
                    </p>
                </div>
            </div> 
        </div> 
    </div>     
    <!-- End Timeline -->
@endsection