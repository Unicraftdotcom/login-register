<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="Asset/Img/logoo.png">
    <!-- bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css" integrity="sha384-Smlep5jCw/wG7hdkwQ/Z5nLIefveQRIY9nfy6xoR1uRYBtpZgI6339F5dgvm/e9B" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js" integrity="sha384-o+RDsa0aLu++PJvFqy8fFScvbHFLtbvScb8AjopnFD+iEQ7wo/CG0xlczd+2O/em" crossorigin="anonymous"></script>
    <!-- End -->
    <!-- jquery CDN -->
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <!-- End -->
    <!-- Set your CSS file below -->
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <!-- end -->
    <!-- set your Js file below -->
    <!-- end -->
    <title>Unicraft | 404 not found</title>
</head>
<body>
    <!-- <div class="hero-img"> -->
    <nav class="navbar fixed-top navbar-expand-lg bg-light shadow p-3 mb-5 bg-white">
        <a href="/" class="navbar-brand">
            <img src="/img/logo.png" height="70px" alt="logo-unicraft"> 
        </a>
        <ul class="nav justify-content-end">
            <li class="nav-item">
                <a href="/artist" class="nav-link">MEET THE ARTIST</a>
            </li>
            <li class="nav-item">
                <a href="/search" class="nav-link">SEARCH</a>
            </li>
            @guest
                <li class="nav-item">
                    <a href="/login" class="nav-link">LOGIN OR JOIN</a>
                </li>
            @else
                <li class="nav-item">
                    <a href="#" class="nav-link">{{Auth::user()->name}}</a>
                </li>
                <li class="nav-item">
                    <a href="/logout" class="nav-link">Logout</a>
                </li>
            @endguest
            <li class="nav-item">
                <a href="" class="nav-link"><i class="material-icons">shopping_cart</i>0</a>
            </li>
        </ul>
        <i class="material-icons nav-link toggle">menu</i>
    </nav>
    <div class="menu-responsive shadow-lg p-3 mb-5 bg-white">
        <center><img src="/img/logo.png" alt=""></center>
        <ul class="nav flex-column ">
            <li class="nav-item"><a href="/artist" class="nav-link">MEET THE ARTIST</a></li>
            <li class="nav-item"><a href="/login" class="nav-link">LOGIN OR JOIN</a></li>
            <li class="nav-item"><a href="/search" class="nav-link">SEARCH</a></li>
            <li class="nav-item"><a href="" class="nav-link"><i class="material-icons">shopping_cart</i>CART 0</a></li>
        </ul>
    </div>
    <div class=" container">
        <div class="text">
        <h1>404 not found</h1>
        <br>
        <h3>we are looking for your page.... but we can't find it</h3>
        <br>
        </div>
    </div>
    <footer class="mainfooter" role="contentinfo">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-12">
                        <center><h4>Contact Us</h4></center>
                        <ul class="list-unstyled">
                            <li>081246967190</li>
                            <li>loremipsum@mail.com</li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-sm-12">
                        <center><h4>Services</h4></center>
                        <ul class="list-unstyled">
                            <li><a href="#">Ordering & Payment</a></li>
                            <li><a href="#">Shipping</a></li>
                            <li><a href="#">Returns</a></li>
                            <li><a href="#">FAQ</a></li>
                            <li><a href="#">Sizing guide</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-sm-12">
                        <center><h4>Information</h4></center>
                        <ul class="list-unstyled">
                            <li><a href="#">Work with Us</a></li>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Terms & Conditions</a></li>
                            <li><a href="#">Press Enquiries</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-sm-12">
                        <div class="float-right">
                           <a href=""><img src="Asset/Img/instagram-logo.png" alt=""></a>
                           <a href=""><img src="Asset/Img/facebook-logo-button.png" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-middle">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <center><h6>&copy; Copyright Unicraft 2018</h6></center>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script>
        $(document).ready(function(){
            $('.toggle').click(function(){
                $('.menu-responsive').toggleClass('active');
            });
        });
    </script>
</body>
</html>