
$(document).ready(function(){
   	$('.toggle').click(function(){
      	$('.menu-responsive').toggleClass('active');
    });
    $('#comsoon').click(function(e){
    	e.preventDefault();
        Push.Permission.request(() => {
          	Push.create('the-unicraft.com',{
                body : 'Dalam proses pengembangan',
                icon : '/img/logoo.png',
                timeout : 3000,
            });
        });
    });
});

// youtube api
var tag = document.createElement('script');

tag.src = 'https://www.youtube.com/iframe_api';
var firstScriptTag = document.getElementsByTagName('script')[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

var uniPlayer;
function onYoutubeIframeApiReady(){
	uniPlayer = new YT.Player('uniPlayer',{
		height  : 100,
		width   : '100%',
		videoId : '1GE-ifjUqmg' && 'FJ-ULEy8uAY',
		events  : {
			'onReady' : onPlayerReady,
			'onStateChange' : onPlayerStateChange,
		}
	});
}

function onPlayerReady(e){
	e.target.playVideo();
}