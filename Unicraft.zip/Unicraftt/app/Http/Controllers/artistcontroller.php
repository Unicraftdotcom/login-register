<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class artistcontroller extends Controller
{
    public function artist(){
    	return view('meettheartist');
    }
}
