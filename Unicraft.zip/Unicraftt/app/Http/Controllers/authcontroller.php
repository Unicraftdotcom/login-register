<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\User;
use Auth;
use Alert;

class authcontroller extends Controller
{
    public function login(){
    	return view('user.login');
    }
    public function postLogin(Request $request){
        //pengujian login
        $this->validate($request,[
            'email' => 'required|email|',
            'password' => 'required'
        ]);
        if (Auth::attempt(['email' => $request->email,'password' => $request->password,])) {
            Alert::success('Success','Anda berhasil daftar');
            return redirect('/');
        }else{
            return redirect()->back();
        }
    }
    public function register(){
    	return view('user.register');
    }
    public function postRegister(Request $request){
    	// validasi
    	$this->validate($request,[
    		'name' => 'required|min:4',
    		'email' => 'required|email|unique:users',
            'noHp' => 'required|min:1|max:12',
            'gender' => 'required',
    		'password' => 'required|confirmed|min:6',
    	]);

    	$user = User::create([
    		'name' => $request->name,
    		'email' => $request->email,
    		'noHp' => $request->noHp,
            'gender' => $request->gender,
            'hakAkses' => 'user',
    		'password' => bcrypt($request->password),
    	]);
        return redirect('/login');
    	if ($user) {
            Alert::success('Success','Anda berhasil daftar');
            return redirect('/login');
        }else{
            return false;
        }
    }

    public function logout(){
        Auth::logout();

        return redirect('/');
    }
}
