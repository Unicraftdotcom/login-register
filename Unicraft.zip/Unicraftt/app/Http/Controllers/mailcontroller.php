<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Newsletter;

class mailcontroller extends Controller
{
    public function subscribe(Request $request){
    	if ( ! Newsletter::isSubscribed($request->email) ) {
        	Newsletter::subscribe($request->email);
        	return redirect('/');
    	}
    }
}
